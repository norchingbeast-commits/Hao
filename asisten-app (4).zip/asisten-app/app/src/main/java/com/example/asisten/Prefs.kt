package com.example.asisten

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("asisten", Context.MODE_PRIVATE)

    fun name(c: Context): String = sp(c).getString("name", "Ariel") ?: "Ariel"
    fun setName(c: Context, v: String) = sp(c).edit().putString("name", v).apply()

    fun size(c: Context): Int = sp(c).getInt("size", 84)
    fun setSize(c: Context, v: Int) = sp(c).edit().putInt("size", v).apply()

    fun notes(c: Context): String = sp(c).getString("notes", "") ?: ""
    fun addNote(c: Context, t: String) =
        sp(c).edit().putString("notes", notes(c) + "- " + t + "\n").apply()
    fun clearNotes(c: Context) = sp(c).edit().remove("notes").apply()

    fun mascotFile(c: Context) = File(c.filesDir, "mascot.png")
    fun mascot(c: Context): Bitmap? {
        val f = mascotFile(c)
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    // alias perintah: "pagi" -> "buka tiktok; scroll down"
    fun aliases(c: Context): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        (sp(c).getString("aliases", "") ?: "").split("\n").forEach { line ->
            val i = line.indexOf('\t')
            if (i > 0) m[line.substring(0, i)] = line.substring(i + 1)
        }
        return m
    }
    private fun saveAliases(c: Context, m: Map<String, String>) =
        sp(c).edit().putString("aliases", m.entries.joinToString("\n") { it.key + "\t" + it.value }).apply()
    fun setAlias(c: Context, k: String, v: String) {
        val m = LinkedHashMap(aliases(c)); m[k] = v; saveAliases(c, m)
    }
    fun delAlias(c: Context, k: String) {
        val m = LinkedHashMap(aliases(c)); m.remove(k); saveAliases(c, m)
    }
}
