package com.example.asisten

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class AssistantService : AccessibilityService() {

    companion object {
        var instance: AssistantService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var commands: Commands
    private lateinit var params: WindowManager.LayoutParams
    private var box: LinearLayout? = null
    private lateinit var img: ImageView
    private lateinit var label: TextView
    private lateinit var input: EditText
    private lateinit var inputRow: LinearLayout
    private lateinit var hideBtn: TextView
    private var minimized = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        instance = this
        commands = Commands(this)
        buildOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        removeOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    // ---------- Overlay ----------

    private fun buildOverlay() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(6), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(0xE60B1424.toInt())
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), 0xFF3DD6F5.toInt())
            }
        }
        box = b

        hideBtn = TextView(this).apply {
            text = "HIDE"
            textSize = 8f
            setTextColor(Color.WHITE)
            setPadding(dp(6), dp(1), dp(6), dp(1))
            background = GradientDrawable().apply { setColor(0xFFE53935.toInt()); cornerRadius = dp(6).toFloat() }
            setOnClickListener { setMinimized(true) }
        }
        b.addView(hideBtn)

        img = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        b.addView(img, LinearLayout.LayoutParams(dp(84), dp(84)))

        label = TextView(this).apply {
            textSize = 10f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 4
        }
        b.addView(label)

        input = EditText(this).apply {
            hint = "Perintah..."
            textSize = 11f
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF8899AA.toInt())
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, a, _ ->
                if (a == EditorInfo.IME_ACTION_GO) { submit(); true } else false
            }
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_DOWN && (params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) != 0) {
                    setFocusable(true)
                    handler.postDelayed({
                        requestFocus()
                        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                            .showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
                    }, 150)
                }
                false
            }
        }
        val go = Button(this).apply {
            text = "GO"
            textSize = 10f
            setPadding(0, 0, 0, 0)
            setOnClickListener { submit() }
        }
        inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(go, LinearLayout.LayoutParams(dp(38), dp(36)))
        }
        b.addView(inputRow)

        // seret & tap maskot
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        img.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = params.x; sy = params.y; dx = e.rawX; dy = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 8 || abs(my) > 8) moved = true
                    if (moved) { params.x = sx + mx; params.y = sy + my; wm.updateViewLayout(b, params) }
                }
                MotionEvent.ACTION_UP -> if (!moved && minimized) setMinimized(false)
            }
            true
        }

        params = WindowManager.LayoutParams(
            dp(170), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - dp(180)
            y = dp(120)
        }

        refresh()
        wm.addView(b, params)
    }

    private fun removeOverlay() {
        try { box?.let { wm.removeView(it) } } catch (_: Exception) {}
        box = null
    }

    /** Dipanggil setelah nama / gambar diganti. */
    fun refresh() {
        val bmp = Prefs.mascot(this)
        if (bmp != null) img.setImageBitmap(bmp) else img.setImageResource(R.drawable.default_mascot)
        label.text = "Halo, saya ${Prefs.name(this)}"
    }

    fun toggleVisible() {
        box?.let { it.visibility = if (it.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
    }

    private fun setMinimized(m: Boolean) {
        minimized = m
        val v = if (m) View.GONE else View.VISIBLE
        hideBtn.visibility = v; label.visibility = v; inputRow.visibility = v
        params.width = if (m) WindowManager.LayoutParams.WRAP_CONTENT else dp(170)
        box?.let { wm.updateViewLayout(it, params) }
    }

    private fun setFocusable(f: Boolean) {
        params.flags = if (f) 0 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        box?.let { wm.updateViewLayout(it, params) }
    }

    private fun say(t: String) { label.text = t }

    private fun submit() {
        val cmd = input.text.toString().trim()
        if (cmd.isEmpty()) return
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        setFocusable(false) // kembalikan fokus ke aplikasi di bawah
        say("Memproses: $cmd")
        handler.postDelayed({ say(commands.run(cmd)) }, 500)
    }

    // ---------- Aksi untuk Commands ----------

    fun global(action: Int) = performGlobalAction(action)

    fun scroll(down: Boolean): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val a = dm.heightPixels * 0.7f
        val b = dm.heightPixels * 0.3f
        val p = Path().apply { moveTo(x, if (down) a else b); lineTo(x, if (down) b else a) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build()
        return dispatchGesture(g, null, null)
    }

    fun tapText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            var x: AccessibilityNodeInfo? = n
            while (x != null) {
                if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                x = x.parent
            }
        }
        return false
    }

    fun typeText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val cur = if (f.isShowingHintText) "" else (f.text?.toString() ?: "")
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, cur + t)
        }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun screenshot() {
        box?.visibility = View.INVISIBLE
        handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) }, 400)
        handler.postDelayed({ box?.visibility = View.VISIBLE }, 2000)
    }
}
