package com.example.asisten

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {

    private lateinit var preview: ImageView
    private lateinit var status: TextView

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) saveImage(uri)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        fun btn(t: String, f: () -> Unit) {
            col.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        }

        col.addView(TextView(this).apply { text = "Pengaturan Asisten"; textSize = 22f })
        status = TextView(this)
        col.addView(status)

        preview = ImageView(this)
        col.addView(preview, LinearLayout.LayoutParams(dp(110), dp(110)))
        btn("Pilih gambar maskot") { pick.launch("image/*") }

        val nameInput = EditText(this).apply { setText(Prefs.name(this@MainActivity)); hint = "Nama asisten" }
        col.addView(nameInput)
        btn("Simpan nama") {
            val n = nameInput.text.toString().trim().ifEmpty { "Asisten" }
            Prefs.setName(this, n)
            AssistantService.instance?.refresh()
            Toast.makeText(this, "Nama disimpan: $n", Toast.LENGTH_SHORT).show()
        }

        btn("1. Aktifkan Aksesibilitas") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("2. Izinkan Kontak & Telepon") {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE), 1)
        }
        btn("Tampilkan / sembunyikan asisten") {
            val s = AssistantService.instance
            if (s == null) Toast.makeText(this, "Aktifkan Aksesibilitas dulu", Toast.LENGTH_SHORT).show()
            else s.toggleVisible()
        }

        col.addView(TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(16), 0, 0)
            text = "CARA PAKAI\n\n" + Commands.MENU
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        showPreview()
        status.text = if (AssistantService.instance != null) "Status: aktif" else "Status: belum aktif (nyalakan Aksesibilitas)"
    }

    private fun showPreview() {
        val b = Prefs.mascot(this)
        if (b != null) preview.setImageBitmap(b) else preview.setImageResource(R.drawable.default_mascot)
    }

    private fun saveImage(uri: Uri) {
        try {
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
            val s = minOf(1f, 400f / maxOf(bmp.width, bmp.height))
            val out = Bitmap.createScaledBitmap(
                bmp, (bmp.width * s).toInt().coerceAtLeast(1), (bmp.height * s).toInt().coerceAtLeast(1), true
            )
            FileOutputStream(Prefs.mascotFile(this)).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            showPreview()
            AssistantService.instance?.refresh()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal memuat gambar", Toast.LENGTH_SHORT).show()
        }
    }
}
