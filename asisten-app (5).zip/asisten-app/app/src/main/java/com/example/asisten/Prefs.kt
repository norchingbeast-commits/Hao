package com.example.asisten

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("asisten", Context.MODE_PRIVATE)

    fun name(c: Context): String = sp(c).getString("name", "Ariel") ?: "Ariel"
    fun setName(c: Context, v: String) = sp(c).edit().putString("name", v).apply()

    fun size(c: Context): Int = sp(c).getInt("size", 84)
    fun setSize(c: Context, v: Int) = sp(c).edit().putInt("size", v).apply()

    fun notes(c: Context): String = sp(c).getString("notes", "") ?: ""
    fun addNote(c: Context, t: String) =
        sp(c).edit().putString("notes", notes(c) + "- " + t + "\n").apply()
    fun clearNotes(c: Context) = sp(c).edit().remove("notes").apply()

    fun mascotFile(c: Context) = File(c.filesDir, "mascot.png")
    fun mascot(c: Context): Bitmap? {
        val f = mascotFile(c)
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    // alias perintah: "pagi" -> "buka tiktok; scroll down"
    fun aliases(c: Context): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        (sp(c).getString("aliases", "") ?: "").split("\n").forEach { line ->
            val i = line.indexOf('\t')
            if (i > 0) m[line.substring(0, i)] = line.substring(i + 1)
        }
        return m
    }
    private fun saveAliases(c: Context, m: Map<String, String>) =
        sp(c).edit().putString("aliases", m.entries.joinToString("\n") { it.key + "\t" + it.value }).apply()
    fun setAlias(c: Context, k: String, v: String) {
        val m = LinkedHashMap(aliases(c)); m[k] = v; saveAliases(c, m)
    }
    fun delAlias(c: Context, k: String) {
        val m = LinkedHashMap(aliases(c)); m.remove(k); saveAliases(c, m)
    }

    // ---------- balas otomatis WhatsApp ----------
    fun arEnabled(c: Context) = sp(c).getBoolean("ar_on", false)
    fun setArEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("ar_on", v).apply()
    fun arGroups(c: Context) = sp(c).getBoolean("ar_groups", false)
    fun setArGroups(c: Context, v: Boolean) = sp(c).edit().putBoolean("ar_groups", v).apply()
    fun arDefaultOn(c: Context) = sp(c).getBoolean("ar_def_on", true)
    fun setArDefaultOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("ar_def_on", v).apply()
    fun arDefault(c: Context): String =
        sp(c).getString("ar_def", "Halo {nama}, saya sedang sibuk. Nanti saya balas ya.") ?: ""
    fun setArDefault(c: Context, v: String) = sp(c).edit().putString("ar_def", v).apply()
    fun arCooldown(c: Context) = sp(c).getInt("ar_cd", 30)
    fun setArCooldown(c: Context, v: Int) = sp(c).edit().putInt("ar_cd", v).apply()
    fun arFrom(c: Context) = sp(c).getInt("ar_from", 0)
    fun arTo(c: Context) = sp(c).getInt("ar_to", 0)
    fun setArHours(c: Context, from: Int, to: Int) =
        sp(c).edit().putInt("ar_from", from).putInt("ar_to", to).apply()

    fun arRules(c: Context): List<Pair<String, String>> =
        (sp(c).getString("ar_rules", "") ?: "").split("\n").mapNotNull { line ->
            val i = line.indexOf('\t')
            if (i > 0) line.substring(0, i) to line.substring(i + 1) else null
        }
    private fun saveRules(c: Context, r: List<Pair<String, String>>) =
        sp(c).edit().putString("ar_rules", r.joinToString("\n") { it.first + "\t" + it.second }).apply()
    private fun clean(t: String) = t.replace('\t', ' ').replace('\n', ' ').trim()
    fun addRule(c: Context, k: String, v: String) = saveRules(c, arRules(c) + (clean(k) to clean(v)))
    fun delRule(c: Context, index: Int) =
        saveRules(c, arRules(c).filterIndexed { i, _ -> i != index })

    fun log(c: Context): String = sp(c).getString("ar_log", "") ?: ""
    fun addLog(c: Context, line: String) {
        val all = (log(c).split("\n").filter { it.isNotBlank() } + clean(line)).takeLast(20)
        sp(c).edit().putString("ar_log", all.joinToString("\n")).apply()
    }
    fun clearLog(c: Context) = sp(c).edit().remove("ar_log").apply()
}
