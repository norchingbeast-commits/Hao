package com.example.asisten

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class AutoReplyActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var rulesBox: LinearLayout
    private lateinit var logView: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }
        fun title(t: String) = col.addView(TextView(this).apply {
            text = t; textSize = 13f
            setTextColor(0xFF3DD6F5.toInt())
            setPadding(0, dp(20), 0, dp(4))
        })
        fun note(t: String) = col.addView(TextView(this).apply { text = t; textSize = 12f })
        fun sw(t: String, on: Boolean, f: (Boolean) -> Unit) = col.addView(Switch(this).apply {
            text = t; isChecked = on
            setOnCheckedChangeListener { _, v -> f(v) }
        })
        fun btn(t: String, f: () -> Unit) = col.addView(Button(this).apply {
            text = t; setOnClickListener { f() }
        })
        fun edit(h: String, v: String): EditText {
            val e = EditText(this).apply { hint = h; setText(v); isSingleLine = true }
            col.addView(e)
            return e
        }

        col.addView(TextView(this).apply { text = "Balas otomatis WhatsApp"; textSize = 22f })
        status = TextView(this)
        col.addView(status)
        note("Membalas lewat notifikasi WhatsApp yang muncul di HP. Pakai secara wajar untuk keperluan pribadi; balas massal atau spam bisa membuat nomor dibatasi WhatsApp.")

        btn("1. Beri akses notifikasi") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        sw("2. Aktifkan balas otomatis", Prefs.arEnabled(this)) { Prefs.setArEnabled(this, it) }
        sw("Balas juga di grup", Prefs.arGroups(this)) { Prefs.setArGroups(this, it) }

        title("BALASAN DEFAULT (bila tidak ada kata kunci cocok)")
        sw("Pakai balasan default", Prefs.arDefaultOn(this)) { Prefs.setArDefaultOn(this, it) }
        val defIn = edit("Isi balasan", Prefs.arDefault(this))
        btn("Simpan balasan default") {
            Prefs.setArDefault(this, defIn.text.toString().trim())
            toast("Disimpan")
        }

        title("ATURAN KATA KUNCI")
        note("Beberapa kata kunci dipisah koma. Di balasan boleh pakai {nama} dan {jam}.")
        val kwIn = edit("Kata kunci (mis. harga, price)", "")
        val rpIn = edit("Balasan (mis. Halo {nama}, harga mulai 50rb)", "")
        btn("Tambah aturan") {
            val k = kwIn.text.toString().trim()
            val r = rpIn.text.toString().trim()
            if (k.isEmpty() || r.isEmpty()) toast("Isi kata kunci dan balasan")
            else {
                Prefs.addRule(this, k, r)
                kwIn.setText(""); rpIn.setText("")
                renderRules()
            }
        }
        rulesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(rulesBox)

        title("PENGATURAN")
        val cd = edit("Jeda antar balasan ke orang yang sama (menit)", Prefs.arCooldown(this).toString())
        cd.inputType = InputType.TYPE_CLASS_NUMBER
        note("Jam aktif (0-23). Dari dan sampai sama = sepanjang hari.")
        val from = edit("Aktif dari jam", Prefs.arFrom(this).toString())
        from.inputType = InputType.TYPE_CLASS_NUMBER
        val to = edit("sampai jam", Prefs.arTo(this).toString())
        to.inputType = InputType.TYPE_CLASS_NUMBER
        btn("Simpan pengaturan") {
            Prefs.setArCooldown(this, (cd.text.toString().toIntOrNull() ?: 30).coerceIn(0, 1440))
            Prefs.setArHours(
                this,
                (from.text.toString().toIntOrNull() ?: 0).coerceIn(0, 23),
                (to.text.toString().toIntOrNull() ?: 0).coerceIn(0, 23)
            )
            toast("Disimpan")
        }

        title("TES (tanpa WhatsApp)")
        val tIn = edit("Ketik contoh pesan masuk", "")
        val tOut = TextView(this)
        btn("Tes balasan") {
            tOut.text = AutoReply.decide(this, "Budi", tIn.text.toString(), false) ?: "(tidak akan membalas)"
        }
        col.addView(tOut)

        title("RIWAYAT BALASAN")
        logView = TextView(this)
        col.addView(logView)
        btn("Hapus riwayat") { Prefs.clearLog(this); showLog() }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0F1724.toInt())
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (hasAccess()) "Akses notifikasi: aktif" else "Akses notifikasi: belum aktif"
        renderRules()
        showLog()
    }

    private fun hasAccess(): Boolean =
        (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "")
            .contains(packageName)

    private fun showLog() {
        logView.text = Prefs.log(this).ifBlank { "Belum ada" }
    }

    private fun renderRules() {
        rulesBox.removeAllViews()
        val rules = Prefs.arRules(this)
        if (rules.isEmpty()) {
            rulesBox.addView(TextView(this).apply { text = "(belum ada aturan)" })
            return
        }
        rules.forEachIndexed { i, (k, r) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(
                TextView(this).apply { text = k + " -> " + r; textSize = 13f },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(Button(this).apply {
                text = "Hapus"
                setOnClickListener { Prefs.delRule(this@AutoReplyActivity, i); renderRules() }
            })
            rulesBox.addView(row)
        }
    }
}
