package com.example.asisten

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Logika memilih balasan (dipakai service dan tombol Tes). */
object AutoReply {

    fun activeNow(c: Context): Boolean {
        val from = Prefs.arFrom(c)
        val to = Prefs.arTo(c)
        if (from == to) return true
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (from < to) h in from until to else (h >= from || h < to)
    }

    fun decide(c: Context, sender: String, text: String, isGroup: Boolean): String? {
        if (isGroup && !Prefs.arGroups(c)) return null
        if (!activeNow(c)) return null
        val t = text.lowercase()
        for ((kw, reply) in Prefs.arRules(c)) {
            val keys = kw.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            if (keys.any { t.contains(it) }) return fill(reply, sender)
        }
        if (Prefs.arDefaultOn(c) && Prefs.arDefault(c).isNotBlank()) return fill(Prefs.arDefault(c), sender)
        return null
    }

    private fun fill(s: String, name: String) =
        s.replace("{nama}", name)
            .replace("{jam}", SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()))
}
