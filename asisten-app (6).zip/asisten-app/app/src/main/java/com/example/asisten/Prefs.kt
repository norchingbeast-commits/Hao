package com.example.asisten

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("asisten", Context.MODE_PRIVATE)

    fun name(c: Context): String = sp(c).getString("name", "Ariel") ?: "Ariel"
    fun setName(c: Context, v: String) = sp(c).edit().putString("name", v).apply()

    fun size(c: Context): Int = sp(c).getInt("size", 84)
    fun setSize(c: Context, v: Int) = sp(c).edit().putInt("size", v).apply()

    fun notes(c: Context): String = sp(c).getString("notes", "") ?: ""
    fun addNote(c: Context, t: String) =
        sp(c).edit().putString("notes", notes(c) + "- " + t + "\n").apply()
    fun clearNotes(c: Context) = sp(c).edit().remove("notes").apply()

    fun mascotFile(c: Context) = File(c.filesDir, "mascot.png")
    fun mascot(c: Context): Bitmap? {
        val f = mascotFile(c)
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    // alias perintah: "pagi" -> "buka tiktok; scroll down"
    fun aliases(c: Context): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        (sp(c).getString("aliases", "") ?: "").split("\n").forEach { line ->
            val i = line.indexOf('\t')
            if (i > 0) m[line.substring(0, i)] = line.substring(i + 1)
        }
        return m
    }
    private fun saveAliases(c: Context, m: Map<String, String>) =
        sp(c).edit().putString("aliases", m.entries.joinToString("\n") { it.key + "\t" + it.value }).apply()
    fun setAlias(c: Context, k: String, v: String) {
        val m = LinkedHashMap(aliases(c)); m[k] = v; saveAliases(c, m)
    }
    fun delAlias(c: Context, k: String) {
        val m = LinkedHashMap(aliases(c)); m.remove(k); saveAliases(c, m)
    }

    // ---------- balas otomatis WhatsApp ----------
    private fun clean(t: String) = t.replace('\t', ' ').replace('\n', ' ').trim()

    fun arEnabled(c: Context) = sp(c).getBoolean("ar_on", false)
    fun setArEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("ar_on", v).apply()
    fun arDefaultOn(c: Context) = sp(c).getBoolean("ar_def_on", true)
    fun setArDefaultOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("ar_def_on", v).apply()
    fun arDefault(c: Context): String =
        sp(c).getString("ar_def", "Halo {nama}, mohon maaf saya sedang sibuk. Pesan Anda akan saya balas secepatnya. Terima kasih.") ?: ""
    fun setArDefault(c: Context, v: String) = sp(c).edit().putString("ar_def", v).apply()
    fun arCooldown(c: Context) = sp(c).getInt("ar_cd", 30)
    fun setArCooldown(c: Context, v: Int) = sp(c).edit().putInt("ar_cd", v).apply()

    // hari aktif: Calendar.DAY_OF_WEEK (1 = Minggu ... 7 = Sabtu)
    fun arDays(c: Context): Set<Int> =
        (sp(c).getString("ar_days", "1234567") ?: "").mapNotNull { it.digitToIntOrNull() }.toSet()
    fun setArDays(c: Context, d: Set<Int>) =
        sp(c).edit().putString("ar_days", d.sorted().joinToString("")).apply()

    // jam aktif dalam menit sejak tengah malam (sama = sepanjang hari)
    fun arFromM(c: Context) = sp(c).getInt("ar_from_m", 0)
    fun arToM(c: Context) = sp(c).getInt("ar_to_m", 0)
    fun setArTimes(c: Context, from: Int, to: Int) =
        sp(c).edit().putInt("ar_from_m", from).putInt("ar_to_m", to).apply()

    // 0 = semua, 1 = hanya daftar, 2 = semua kecuali daftar
    fun arPeopleMode(c: Context) = sp(c).getInt("ar_people_mode", 0)
    fun setArPeopleMode(c: Context, v: Int) = sp(c).edit().putInt("ar_people_mode", v).apply()
    // 0 = tidak dibalas, 1 = hanya daftar, 2 = semua grup
    fun arGroupMode(c: Context) = sp(c).getInt("ar_group_mode", 0)
    fun setArGroupMode(c: Context, v: Int) = sp(c).edit().putInt("ar_group_mode", v).apply()

    private fun getList(c: Context, k: String): List<String> =
        (sp(c).getString(k, "") ?: "").split("\n").filter { it.isNotBlank() }
    private fun putList(c: Context, k: String, l: List<String>) =
        sp(c).edit().putString(k, l.joinToString("\n")).apply()
    private fun listKey(group: Boolean) = if (group) "ar_group_list" else "ar_people_list"

    fun arList(c: Context, group: Boolean): List<String> = getList(c, listKey(group))
    fun arAdd(c: Context, group: Boolean, name: String) {
        val n = clean(name)
        if (n.isEmpty()) return
        val l = arList(c, group)
        if (l.any { it.equals(n, true) }) return
        putList(c, listKey(group), l + n)
    }
    fun arDel(c: Context, group: Boolean, index: Int) =
        putList(c, listKey(group), arList(c, group).filterIndexed { i, _ -> i != index })

    // nama chat yang terdeteksi dari notifikasi (untuk dipilih tanpa mengetik)
    fun arSeen(c: Context, group: Boolean): List<String> =
        getList(c, if (group) "ar_seen_group" else "ar_seen_people")
    fun arAddSeen(c: Context, group: Boolean, name: String) {
        val n = clean(name)
        if (n.isEmpty()) return
        val k = if (group) "ar_seen_group" else "ar_seen_people"
        putList(c, k, (listOf(n) + getList(c, k).filter { !it.equals(n, true) }).take(30))
    }

    // aturan kata kunci
    fun arRules(c: Context): List<Pair<String, String>> =
        (sp(c).getString("ar_rules", "") ?: "").split("\n").mapNotNull { line ->
            val i = line.indexOf('\t')
            if (i > 0) line.substring(0, i) to line.substring(i + 1) else null
        }
    private fun saveRules(c: Context, r: List<Pair<String, String>>) =
        sp(c).edit().putString("ar_rules", r.joinToString("\n") { it.first + "\t" + it.second }).apply()
    fun addRule(c: Context, k: String, v: String) = saveRules(c, arRules(c) + (clean(k) to clean(v)))
    fun delRule(c: Context, index: Int) =
        saveRules(c, arRules(c).filterIndexed { i, _ -> i != index })

    // riwayat
    fun log(c: Context): String = sp(c).getString("ar_log", "") ?: ""
    fun addLog(c: Context, line: String) {
        val all = (log(c).split("\n").filter { it.isNotBlank() } + clean(line)).takeLast(20)
        sp(c).edit().putString("ar_log", all.joinToString("\n")).apply()
    }
    fun clearLog(c: Context) = sp(c).edit().remove("ar_log").apply()
}
