package com.example.asisten

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Commands(private val svc: AssistantService) {

    companion object {
        const val MENU = """APLIKASI & WEB
- buka [app / situs]
- cari [kata]
- yt [kata]  (YouTube)
- maps [tempat]
- terjemah [teks]

KOMUNIKASI
- telepon [nama / nomor]
- wa [nama / nomor]
- wa [nama] : [pesan]

KONTROL HP
- senter (on / off)
- volume naik / turun
- scroll down / up
- geser kiri / kanan
- screenshot
- home / kembali / terbaru
- notifikasi
- tidur  (kunci layar)
- setelan [wifi / bluetooth / layar / suara / lokasi]

LAYAR
- ketik [teks]  (tap kolom teksnya dulu)
- tempel
- tap [teks di layar]
- salin [teks]

PRODUKTIVITAS
- alarm 07:30 [pesan]
- timer 5 menit
- hitung 12*5+3
- catat [teks] / catatan / bersihkan
- jam / tanggal / baterai / status

OTOMATIS
- balas on / balas off  (balas otomatis WhatsApp)
- alias [nama] = [perintah]
- alias  (lihat daftar)
- hapus alias [nama]
- gabung perintah dengan titik koma:
  buka tiktok; scroll down"""
    }

    private class App(val info: ResolveInfo, val label: String)

    private var apps: List<App>? = null
    private var torchOn = false

    private fun go(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        svc.startActivity(i)
    }

    private fun web(url: String, msg: String): String {
        go(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        return msg
    }

    private fun gesture(ok: Boolean, msg: String) =
        if (ok) msg else "Gagal (cek Aksesibilitas)"

    fun run(raw: String, depth: Int = 0): String {
        val t = raw.trim()
        if (t.isEmpty()) return "Ketik perintah dulu"
        if (t.contains(';') && depth < 3) {
            return t.split(';').map { it.trim() }.filter { it.isNotEmpty() }
                .joinToString("\n") { run(it, depth + 1) }
        }
        val l = t.lowercase(Locale.ROOT)
        fun arg(p: String) = t.substring(p.length).trim()

        val alias = Prefs.aliases(svc)[l]
        if (alias != null && depth < 3) return run(alias, depth + 1)

        return try {
            when {
                l == "menu" || l == "bantuan" -> { go(Intent(svc, MainActivity::class.java)); "Membuka menu..." }

                l.startsWith("buka ") -> openApp(arg("buka "))
                l.startsWith("cari ") -> web("https://www.google.com/search?q=" + Uri.encode(arg("cari ")), "Mencari: ${arg("cari ")}")
                l.startsWith("yt ") -> web("https://www.youtube.com/results?search_query=" + Uri.encode(arg("yt ")), "YouTube: ${arg("yt ")}")
                l.startsWith("maps ") -> web("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(arg("maps ")), "Maps: ${arg("maps ")}")
                l.startsWith("terjemah ") -> web("https://translate.google.com/?sl=auto&tl=id&op=translate&text=" + Uri.encode(arg("terjemah ")), "Menerjemahkan...")

                l.startsWith("telepon ") -> call(arg("telepon "))
                l.startsWith("wa ") -> wa(arg("wa "))

                l == "senter" -> torch(!torchOn)
                l == "senter on" -> torch(true)
                l == "senter off" -> torch(false)
                l == "volume naik" -> volume(AudioManager.ADJUST_RAISE)
                l == "volume turun" -> volume(AudioManager.ADJUST_LOWER)
                l == "scroll down" -> gesture(svc.swipe(0.5f, 0.7f, 0.5f, 0.3f), "Scroll ke bawah")
                l == "scroll up" -> gesture(svc.swipe(0.5f, 0.3f, 0.5f, 0.7f), "Scroll ke atas")
                l == "geser kiri" -> gesture(svc.swipe(0.8f, 0.5f, 0.2f, 0.5f), "Geser kiri")
                l == "geser kanan" -> gesture(svc.swipe(0.2f, 0.5f, 0.8f, 0.5f), "Geser kanan")
                l == "screenshot" -> { svc.screenshot(); "Mengambil screenshot..." }
                l == "home" -> gesture(svc.global(AccessibilityService.GLOBAL_ACTION_HOME), "Home")
                l == "kembali" -> gesture(svc.global(AccessibilityService.GLOBAL_ACTION_BACK), "Kembali")
                l == "terbaru" -> gesture(svc.global(AccessibilityService.GLOBAL_ACTION_RECENTS), "Aplikasi terbaru")
                l == "notifikasi" -> gesture(svc.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS), "Notifikasi")
                l == "balas on" -> { Prefs.setArEnabled(svc, true); "Balas otomatis WA aktif" }
                l == "balas off" -> { Prefs.setArEnabled(svc, false); "Balas otomatis WA mati" }
                l == "tidur" -> gesture(svc.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN), "Layar dikunci")
                l == "setelan" || l.startsWith("setelan ") -> settings(l.removePrefix("setelan").trim())
                l == "wifi" -> settings("wifi")
                l == "bluetooth" -> settings("bluetooth")

                l.startsWith("ketik ") ->
                    if (svc.typeText(arg("ketik "))) "Teks diketik" else "Tidak ada kolom teks aktif. Tap kolomnya dulu."
                l == "tempel" -> if (svc.paste()) "Ditempel" else "Tidak ada kolom teks aktif"
                l.startsWith("tap ") ->
                    if (svc.tapText(arg("tap "))) "Tap: ${arg("tap ")}" else "Teks tidak ditemukan di layar"
                l.startsWith("salin ") -> {
                    val cm = svc.getSystemService(ClipboardManager::class.java)
                    cm.setPrimaryClip(ClipData.newPlainText("asisten", arg("salin ")))
                    "Disalin"
                }

                l.startsWith("alarm ") -> alarm(arg("alarm "))
                l.startsWith("timer ") -> timer(arg("timer "))
                l.startsWith("hitung ") -> "= " + calc(arg("hitung "))
                l.startsWith("catat ") -> { Prefs.addNote(svc, arg("catat ")); "Catatan disimpan" }
                l == "catatan" -> Prefs.notes(svc).ifBlank { "Belum ada catatan" }
                l == "bersihkan" -> { Prefs.clearNotes(svc); "Catatan dibersihkan" }
                l == "jam" -> SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                l == "tanggal" -> SimpleDateFormat("EEEE, d MMMM yyyy", Locale("id", "ID")).format(Date())
                l == "baterai" -> "Baterai ${battery()}%"
                l == "status" -> "${Prefs.name(svc)} aktif\nBaterai ${battery()}%\nJam " +
                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

                l == "alias" -> Prefs.aliases(svc).entries.joinToString("\n") { "${it.key} = ${it.value}" }
                    .ifBlank { "Belum ada alias. Contoh: alias pagi = buka tiktok; scroll down" }
                l.startsWith("alias ") -> setAlias(arg("alias "))
                l.startsWith("hapus alias ") -> { Prefs.delAlias(svc, arg("hapus alias ").lowercase()); "Alias dihapus" }

                else -> "Perintah tidak dikenal. Ketik: menu"
            }
        } catch (e: Exception) {
            "Gagal: ${e.message}"
        }
    }

    private fun setAlias(a: String): String {
        if (!a.contains("=")) return "Format: alias nama = perintah"
        val k = a.substringBefore("=").trim().lowercase()
        val v = a.substringAfter("=").trim()
        if (k.isEmpty() || v.isEmpty()) return "Format: alias nama = perintah"
        Prefs.setAlias(svc, k, v)
        return "Alias '$k' disimpan"
    }

    // ---------- aplikasi ----------

    private fun loadApps(): List<App> {
        val pm = svc.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(main, 0).map { App(it, it.loadLabel(pm).toString()) }
        apps = list
        return list
    }

    private fun findApp(q: String, list: List<App>): App? =
        list.firstOrNull { it.label.equals(q, true) } ?: list.firstOrNull { it.label.contains(q, true) }

    private fun openApp(q: String): String {
        if (q.contains(".") && !q.contains(" ")) {
            return web(if (q.startsWith("http")) q else "https://$q", "Membuka $q")
        }
        val hit = findApp(q, apps ?: loadApps()) ?: findApp(q, loadApps())
        if (hit != null) {
            val i = svc.packageManager.getLaunchIntentForPackage(hit.info.activityInfo.packageName)
            if (i != null) { go(i); return "Membuka ${hit.label}" }
        }
        if (q.equals("kamera", true) || q.equals("camera", true)) {
            go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); return "Membuka kamera"
        }
        return "Aplikasi '$q' tidak ditemukan"
    }

    // ---------- kontak ----------

    private fun hasContactPerm() =
        svc.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun findContact(q: String): Pair<String, String>? {
        if (q.none { it.isLetter() }) return q to q
        if (!hasContactPerm()) return null
        val c = svc.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$q%"), null
        )
        c?.use { if (it.moveToFirst()) return it.getString(0) to it.getString(1) }
        return null
    }

    private fun contactError(q: String) =
        if (q.any { it.isLetter() } && !hasContactPerm())
            "Izin Kontak belum diberikan. Buka aplikasi > Izinkan Kontak & Telepon"
        else "Kontak '$q' tidak ditemukan"

    private fun call(q: String): String {
        val (name, num) = findContact(q) ?: return contactError(q)
        val granted = svc.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        go(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))))
        return "Menelepon $name"
    }

    private fun wa(q: String): String {
        val who = if (q.contains(":")) q.substringBefore(":").trim() else q
        val msg = if (q.contains(":")) q.substringAfter(":").trim() else ""
        val (name, num) = findContact(who) ?: return contactError(who)
        var n = num.filter { it.isDigit() }
        if (n.startsWith("0")) n = "62" + n.substring(1)
        val url = "https://wa.me/$n" + if (msg.isNotEmpty()) "?text=" + Uri.encode(msg) else ""
        go(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        return "Membuka WhatsApp $name"
    }

    // ---------- perangkat ----------

    private fun torch(on: Boolean): String {
        val cm = svc.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Senter tidak tersedia"
        cm.setTorchMode(id, on)
        torchOn = on
        return if (on) "Senter menyala" else "Senter mati"
    }

    private fun volume(dir: Int): String {
        svc.getSystemService(AudioManager::class.java)
            .adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        return "Volume diubah"
    }

    private fun battery(): Int =
        svc.getSystemService(BatteryManager::class.java)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

    private fun settings(k: String): String {
        val a = when (k) {
            "" -> Settings.ACTION_SETTINGS
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "layar" -> Settings.ACTION_DISPLAY_SETTINGS
            "suara" -> Settings.ACTION_SOUND_SETTINGS
            "lokasi" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            else -> null
        } ?: return "Setelan '$k' tidak dikenal"
        go(Intent(a))
        return "Membuka setelan " + k.ifEmpty { "utama" }
    }

    // ---------- alarm, timer, hitung ----------

    private fun alarm(a: String): String {
        val m = Regex("(\\d{1,2})[:.](\\d{2})\\s*(.*)").matchEntire(a.trim())
            ?: return "Format: alarm 07:30 bangun tidur"
        val h = m.groupValues[1].toInt()
        val mn = m.groupValues[2].toInt()
        if (h > 23 || mn > 59) return "Jam tidak valid"
        go(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, mn)
                .putExtra(AlarmClock.EXTRA_MESSAGE, m.groupValues[3])
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return "Alarm " + String.format(Locale.US, "%02d:%02d", h, mn) + " dibuat"
    }

    private fun timer(a: String): String {
        val m = Regex("(\\d+)\\s*(detik|menit|jam)?").matchEntire(a.trim().lowercase())
            ?: return "Format: timer 5 menit"
        val n = m.groupValues[1].toInt()
        val sec = when (m.groupValues[2]) {
            "detik" -> n
            "jam" -> n * 3600
            else -> n * 60
        }
        go(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return "Timer ${a.trim()} dimulai"
    }

    private class Calc(val s: String) {
        var p = 0
        fun parse(): Double {
            val v = expr()
            if (p != s.length) throw IllegalArgumentException("format salah")
            return v
        }
        fun expr(): Double {
            var v = term()
            while (p < s.length && (s[p] == '+' || s[p] == '-')) {
                val op = s[p++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }
        fun term(): Double {
            var v = factor()
            while (p < s.length && (s[p] == '*' || s[p] == '/')) {
                val op = s[p++]
                val r = factor()
                v = if (op == '*') v * r else v / r
            }
            return v
        }
        fun factor(): Double {
            if (p >= s.length) throw IllegalArgumentException("format salah")
            if (s[p] == '-') { p++; return -factor() }
            if (s[p] == '(') {
                p++
                val v = expr()
                if (p >= s.length || s[p] != ')') throw IllegalArgumentException("kurung tidak lengkap")
                p++
                return v
            }
            val st = p
            while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
            if (st == p) throw IllegalArgumentException("format salah")
            return s.substring(st, p).toDouble()
        }
    }

    private fun calc(e: String): String {
        val s = e.lowercase().replace(" ", "").replace(',', '.').replace('x', '*').replace(':', '/')
        val v = Calc(s).parse()
        if (v.isNaN() || v.isInfinite()) return "tidak valid"
        return if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else String.format(Locale.US, "%.6f", v).trimEnd('0').trimEnd('.')
    }
}
