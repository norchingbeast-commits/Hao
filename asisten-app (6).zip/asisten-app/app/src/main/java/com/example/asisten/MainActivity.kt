package com.example.asisten

import android.Manifest
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {

    private lateinit var preview: ImageView
    private lateinit var status: TextView

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) saveImage(uri)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }
        fun section(t: String) = col.addView(TextView(this).apply {
            text = t; textSize = 13f
            setTextColor(0xFF3DD6F5.toInt())
            setPadding(0, dp(22), 0, dp(4))
        })
        fun btn(t: String, f: () -> Unit) {
            col.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        }

        col.addView(TextView(this).apply { text = "Asisten"; textSize = 26f })
        status = TextView(this)
        col.addView(status)

        // ---- Tampilan ----
        section("TAMPILAN")
        preview = ImageView(this)
        col.addView(preview, LinearLayout.LayoutParams(dp(110), dp(110)))
        btn("Pilih gambar maskot") { pick.launch("image/*") }

        val nameInput = EditText(this).apply { setText(Prefs.name(this@MainActivity)); hint = "Nama asisten" }
        col.addView(nameInput)
        btn("Simpan nama") {
            val n = nameInput.text.toString().trim().ifEmpty { "Asisten" }
            Prefs.setName(this, n)
            AssistantService.instance?.refresh()
            toast("Nama disimpan: $n")
        }

        val sizeLabel = TextView(this).apply { text = "Ukuran maskot: ${Prefs.size(this@MainActivity)}" }
        col.addView(sizeLabel)
        col.addView(SeekBar(this).apply {
            max = 112
            progress = Prefs.size(this@MainActivity) - 48
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    sizeLabel.text = "Ukuran maskot: ${p + 48}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    Prefs.setSize(this@MainActivity, (s?.progress ?: 36) + 48)
                    AssistantService.instance?.refresh()
                }
            })
        })

        // ---- Ikon layar utama ----
        section("IKON DI LAYAR UTAMA (nama & gambar sendiri)")
        val iconName = EditText(this).apply { setText(Prefs.name(this@MainActivity)); hint = "Nama ikon" }
        col.addView(iconName)
        btn("Buat ikon di layar utama") {
            pinShortcut(iconName.text.toString().trim().ifEmpty { Prefs.name(this) })
        }
        col.addView(TextView(this).apply {
            text = "Memakai gambar maskot di atas. Ketuk ikonnya untuk langsung mengetik perintah."
            textSize = 12f
        })

        // ---- Balas otomatis ----
        section("BALAS OTOMATIS WHATSAPP")
        btn("Atur balas otomatis") { startActivity(Intent(this, AutoReplyActivity::class.java)) }

        // ---- Izin ----
        section("IZIN")
        btn("1. Aktifkan Aksesibilitas") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2. Izinkan Kontak & Telepon") {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE), 1)
        }
        btn("Tampilkan / sembunyikan asisten") {
            val s = AssistantService.instance
            if (s == null) toast("Aktifkan Aksesibilitas dulu") else s.toggleVisible()
        }

        // ---- Tes ----
        section("TES PERINTAH")
        val cmdInput = EditText(this).apply { hint = "mis. status, hitung 12*5, jam" }
        col.addView(cmdInput)
        btn("Kirim perintah") {
            val s = AssistantService.instance
            if (s == null) toast("Aktifkan Aksesibilitas dulu")
            else Toast.makeText(this, s.runCommand(cmdInput.text.toString()), Toast.LENGTH_LONG).show()
        }

        // ---- Cara pakai ----
        section("CARA PAKAI")
        col.addView(TextView(this).apply { textSize = 15f; text = Commands.MENU })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0F1724.toInt())
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        showPreview()
        status.text = if (AssistantService.instance != null) "Status: aktif" else "Status: belum aktif (nyalakan Aksesibilitas)"
    }

    private fun showPreview() {
        val b = Prefs.mascot(this)
        if (b != null) preview.setImageBitmap(b) else preview.setImageResource(R.drawable.default_mascot)
    }

    private fun saveImage(uri: Uri) {
        try {
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
            val s = minOf(1f, 400f / maxOf(bmp.width, bmp.height))
            val out = Bitmap.createScaledBitmap(
                bmp, (bmp.width * s).toInt().coerceAtLeast(1), (bmp.height * s).toInt().coerceAtLeast(1), true
            )
            FileOutputStream(Prefs.mascotFile(this)).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            showPreview()
            AssistantService.instance?.refresh()
        } catch (e: Exception) {
            toast("Gagal memuat gambar")
        }
    }

    private fun pinShortcut(label: String) {
        val bmp = Prefs.mascot(this)
        if (bmp == null) { toast("Pilih gambar maskot dulu"); return }
        val sm = getSystemService(ShortcutManager::class.java)
        if (!sm.isRequestPinShortcutSupported) { toast("Launcher tidak mendukung ikon pintasan"); return }
        val size = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - size) / 2, (bmp.height - size) / 2, size, size)
        val info = ShortcutInfo.Builder(this, "asisten_" + System.currentTimeMillis())
            .setShortLabel(label)
            .setLongLabel(label)
            .setIcon(Icon.createWithBitmap(sq))
            .setIntent(Intent(this, InputActivity::class.java).setAction(Intent.ACTION_MAIN))
            .build()
        sm.requestPinShortcut(info, null)
    }
}
