package com.example.asisten

import android.app.Notification
import android.app.RemoteInput
import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Membalas notifikasi WhatsApp lewat tombol "Balas" di notifikasi. */
class AutoReplyService : NotificationListenerService() {

    private val handler = Handler(Looper.getMainLooper())
    private val lastReply = HashMap<String, Long>()
    private val lastText = HashMap<String, String>()
    private val systemText = Regex("^\\d+ (pesan baru|new messages?).*", RegexOption.IGNORE_CASE)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try { handle(sbn) } catch (_: Exception) {}
    }

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        if (title.isBlank() || title == "WhatsApp" || systemText.matches(text)) return
        val isGroup = ex.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)
        val chat = chatName(ex, title, isGroup)
        // di grup, teks biasanya "Pengirim: isi pesan"
        val who = if (isGroup && text.contains(": ")) text.substringBefore(": ") else chat

        Prefs.arAddSeen(this, isGroup, chat)   // catat nama chat agar bisa dipilih di pengaturan
        if (!Prefs.arEnabled(this)) return

        if (lastText[sbn.key] == text) return
        lastText[sbn.key] = text

        val reply = AutoReply.evaluate(this, chat, who, text, isGroup).reply ?: return
        val now = System.currentTimeMillis()
        if (now - (lastReply[chat] ?: 0L) < Prefs.arCooldown(this) * 60_000L) return
        val action = findReplyAction(n) ?: return
        lastReply[chat] = now

        handler.postDelayed({
            if (send(action, reply)) Prefs.addLog(this, "$chat: $reply")
        }, (1500..4000).random().toLong())
    }

    private fun chatName(ex: Bundle, title: String, isGroup: Boolean): String {
        if (!isGroup) return title
        val conv = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
        val base = if (!conv.isNullOrBlank()) conv else title
        return base.substringAfter(" @ ").substringBefore(" (").trim()
    }

    private fun findReplyAction(n: Notification): Notification.Action? {
        val list = ArrayList<Notification.Action>()
        n.actions?.let { list.addAll(it.toList()) }
        list.addAll(Notification.WearableExtender(n).actions)
        return list.firstOrNull { a -> a.remoteInputs != null && a.remoteInputs.isNotEmpty() }
    }

    private fun send(a: Notification.Action, text: String): Boolean {
        return try {
            val inputs = a.remoteInputs ?: return false
            val data = Bundle()
            for (ri in inputs) data.putCharSequence(ri.resultKey, text)
            val intent = Intent()
            RemoteInput.addResultsToIntent(inputs, intent, data)
            a.actionIntent.send(this, 0, intent)
            true
        } catch (e: PendingIntent.CanceledException) {
            false
        } catch (e: Exception) {
            false
        }
    }
}
