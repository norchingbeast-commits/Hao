package com.example.asisten

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Logika memilih balasan (dipakai service dan tombol Tes). */
object AutoReply {

    class Result(val reply: String?, val note: String)

    private val dayNames = listOf("Sen" to 2, "Sel" to 3, "Rab" to 4, "Kam" to 5, "Jum" to 6, "Sab" to 7, "Min" to 1)

    fun fmt(min: Int): String = String.format(Locale.US, "%02d:%02d", min / 60, min % 60)

    private fun inHours(c: Context): Boolean {
        val from = Prefs.arFromM(c)
        val to = Prefs.arToM(c)
        if (from == to) return true
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (from < to) now in from until to else (now >= from || now < to)
    }

    private fun digits(s: String) = s.filter { it.isDigit() }

    /** Cocok bila nama mengandung entri, atau 8 digit terakhir nomor sama. */
    fun matches(entry: String, name: String): Boolean {
        val e = entry.trim().lowercase()
        val n = name.lowercase()
        if (e.isEmpty()) return false
        if (n.contains(e)) return true
        val de = digits(e)
        val dn = digits(n)
        return de.length >= 8 && dn.length >= 8 && dn.takeLast(8) == de.takeLast(8)
    }

    /**
     * chat = nama chat/grup di notifikasi, who = nama pengirim (untuk {nama}).
     */
    fun evaluate(
        c: Context, chat: String, who: String, text: String, isGroup: Boolean,
        ignoreSchedule: Boolean = false
    ): Result {
        if (!ignoreSchedule) {
            val today = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
            if (today !in Prefs.arDays(c)) return Result(null, "Hari ini bukan hari aktif")
            if (!inHours(c)) return Result(null, "Di luar jam aktif")
        }
        if (isGroup) {
            when (Prefs.arGroupMode(c)) {
                0 -> return Result(null, "Grup tidak dibalas (pengaturan grup: tidak)")
                1 -> if (Prefs.arList(c, true).none { matches(it, chat) })
                    return Result(null, "Grup '$chat' tidak ada di daftar grup")
            }
        } else {
            val hit = Prefs.arList(c, false).any { matches(it, chat) }
            when (Prefs.arPeopleMode(c)) {
                1 -> if (!hit) return Result(null, "'$chat' tidak ada di daftar yang dibalas")
                2 -> if (hit) return Result(null, "'$chat' ada di daftar pengecualian")
            }
        }
        val t = text.lowercase()
        for ((kw, reply) in Prefs.arRules(c)) {
            val keys = kw.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            if (keys.any { t.contains(it) }) return Result(fill(reply, who), "Cocok kata kunci: $kw")
        }
        if (Prefs.arDefaultOn(c) && Prefs.arDefault(c).isNotBlank())
            return Result(fill(Prefs.arDefault(c), who), "Memakai balasan default")
        return Result(null, "Tidak ada kata kunci cocok dan balasan default mati")
    }

    fun summary(c: Context): String {
        val days = Prefs.arDays(c)
        val dayText = when {
            days.size == 7 -> "setiap hari"
            days.isEmpty() -> "tidak ada hari (tidak akan membalas)"
            else -> dayNames.filter { it.second in days }.joinToString(", ") { it.first }
        }
        val from = Prefs.arFromM(c)
        val to = Prefs.arToM(c)
        val time = if (from == to) "sepanjang hari" else "pukul ${fmt(from)}-${fmt(to)}"
        val people = when (Prefs.arPeopleMode(c)) {
            1 -> "hanya ${Prefs.arList(c, false).size} orang di daftar"
            2 -> "semua kecuali ${Prefs.arList(c, false).size} orang di daftar"
            else -> "semua orang"
        }
        val groups = when (Prefs.arGroupMode(c)) {
            1 -> "hanya ${Prefs.arList(c, true).size} grup di daftar"
            2 -> "semua grup"
            else -> "tidak dibalas"
        }
        return "Ringkasan: membalas $dayText, $time.\nChat pribadi: $people.\nGrup: $groups."
    }

    private fun fill(s: String, name: String) =
        s.replace("{nama}", name)
            .replace("{jam}", SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()))
}
