package com.example.asisten

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class AutoReplyActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var summary: TextView
    private lateinit var rulesBox: LinearLayout
    private lateinit var logView: TextView
    private lateinit var fromBtn: Button
    private lateinit var toBtn: Button
    private lateinit var peopleBox: LinearLayout
    private lateinit var groupBox: LinearLayout
    private lateinit var peopleSeen: LinearLayout
    private lateinit var groupSeen: LinearLayout
    private val dayChips = LinkedHashMap<Int, TextView>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun lp() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(40))
        }
        fun title(t: String) = col.addView(TextView(this).apply {
            text = t; textSize = 14f
            setTextColor(0xFF3DD6F5.toInt())
            setPadding(0, dp(24), 0, dp(4))
        })
        fun note(t: String) = col.addView(TextView(this).apply { text = t; textSize = 12f })
        fun sw(t: String, on: Boolean, f: (Boolean) -> Unit) = col.addView(Switch(this).apply {
            text = t; isChecked = on
            setOnCheckedChangeListener { _, v -> f(v) }
        })
        fun btn(t: String, f: () -> Unit) = col.addView(Button(this).apply {
            text = t; setOnClickListener { f() }
        })
        fun edit(h: String, v: String): EditText {
            val e = EditText(this).apply { hint = h; setText(v); isSingleLine = true }
            col.addView(e)
            return e
        }
        fun spinner(items: List<String>, selected: Int, onSel: (Int) -> Unit) {
            val s = Spinner(this)
            s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
            s.setSelection(selected)
            s.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(pos) }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
            col.addView(s)
        }

        col.addView(TextView(this).apply { text = "Balas otomatis WhatsApp"; textSize = 22f })
        status = TextView(this)
        col.addView(status)
        summary = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFFB8E8C0.toInt())
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply { setColor(0xFF16263A.toInt()); cornerRadius = dp(8).toFloat() }
        }
        col.addView(summary, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        // ---------- 1. AKTIFKAN ----------
        title("1. AKTIFKAN")
        btn("Beri akses notifikasi") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        sw("Aktifkan balas otomatis", Prefs.arEnabled(this)) { Prefs.setArEnabled(this, it) }
        note("Pakai secara wajar untuk keperluan pribadi. Balas massal atau spam bisa membuat nomor dibatasi WhatsApp.")

        // ---------- 2. JADWAL ----------
        title("2. JADWAL: KAPAN MEMBALAS")
        note("Hari aktif (biru = aktif, ketuk untuk mengubah):")
        val daysRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val labels = listOf("Sen" to 2, "Sel" to 3, "Rab" to 4, "Kam" to 5, "Jum" to 6, "Sab" to 7, "Min" to 1)
        for ((lb, d) in labels) {
            val tv = TextView(this).apply {
                text = lb
                gravity = Gravity.CENTER
                textSize = 12f
                setPadding(0, dp(12), 0, dp(12))
                setOnClickListener {
                    val cur = Prefs.arDays(this@AutoReplyActivity).toMutableSet()
                    if (!cur.add(d)) cur.remove(d)
                    Prefs.setArDays(this@AutoReplyActivity, cur)
                    renderAll()
                }
            }
            dayChips[d] = tv
            daysRow.addView(tv, lp().apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        col.addView(daysRow)

        note("Jam aktif (ketuk untuk mengubah. Mulai dan selesai sama = sepanjang hari):")
        fromBtn = Button(this).apply { setOnClickListener { pickTime(true) } }
        toBtn = Button(this).apply { setOnClickListener { pickTime(false) } }
        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        timeRow.addView(fromBtn, lp())
        timeRow.addView(toBtn, lp())
        col.addView(timeRow)
        btn("Atur cepat: jam sekolah (Sen-Jum, 07:30-13:00)") {
            Prefs.setArDays(this, setOf(2, 3, 4, 5, 6))
            Prefs.setArTimes(this, 7 * 60 + 30, 13 * 60)
            renderAll()
        }
        btn("Atur cepat: setiap hari, sepanjang hari") {
            Prefs.setArDays(this, setOf(1, 2, 3, 4, 5, 6, 7))
            Prefs.setArTimes(this, 0, 0)
            renderAll()
        }

        // ---------- 3. SIAPA ----------
        title("3. SIAPA YANG DIBALAS: CHAT PRIBADI")
        spinner(
            listOf("Balas semua orang", "Balas HANYA yang ada di daftar", "Balas semua KECUALI yang ada di daftar"),
            Prefs.arPeopleMode(this)
        ) { Prefs.setArPeopleMode(this, it); updateSummary() }
        note("Daftar nama atau nomor. Cocok bila nama kontak di notifikasi mengandung tulisan itu (misal \"Ibu\" cocok dengan \"Ibu Rina\").")
        peopleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(peopleBox)
        val pIn = edit("Ketik nama atau nomor (mis. Budi atau 0812xxxx)", "")
        val pRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        pRow.addView(Button(this).apply {
            text = "Tambah"
            setOnClickListener {
                Prefs.arAdd(this@AutoReplyActivity, false, pIn.text.toString())
                pIn.setText(""); renderAll()
            }
        }, lp())
        pRow.addView(Button(this).apply {
            text = "Pilih dari kontak"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI), 7)
            }
        }, lp())
        col.addView(pRow)
        note("Terdeteksi baru-baru ini (dari pesan yang masuk):")
        peopleSeen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(peopleSeen)

        title("3b. SIAPA YANG DIBALAS: GRUP")
        spinner(
            listOf("Jangan balas grup apa pun", "Balas HANYA grup yang ada di daftar", "Balas semua grup"),
            Prefs.arGroupMode(this)
        ) { Prefs.setArGroupMode(this, it); updateSummary() }
        note("Daftar nama grup. Paling mudah: tunggu ada pesan masuk dari grup itu, lalu ketuk + Tambah di bawah.")
        groupBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(groupBox)
        val gIn = edit("Ketik nama grup (mis. Kelas 12 IPA)", "")
        btn("Tambah grup") {
            Prefs.arAdd(this, true, gIn.text.toString())
            gIn.setText(""); renderAll()
        }
        note("Terdeteksi baru-baru ini (dari pesan grup yang masuk):")
        groupSeen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(groupSeen)

        // ---------- 4. ISI BALASAN ----------
        title("4. ISI BALASAN")
        sw("Pakai balasan default (bila tidak ada kata kunci cocok)", Prefs.arDefaultOn(this)) {
            Prefs.setArDefaultOn(this, it)
        }
        val defIn = edit("Isi balasan default", Prefs.arDefault(this))
        btn("Simpan balasan default") {
            Prefs.setArDefault(this, defIn.text.toString().trim())
            toast("Disimpan")
        }
        note("Aturan kata kunci: kalau pesan masuk mengandung kata kunci, dibalas dengan isi khusus. Beberapa kata kunci dipisah koma. Di balasan boleh pakai {nama} dan {jam}.")
        val kwIn = edit("Kata kunci (mis. harga, price)", "")
        val rpIn = edit("Balasan (mis. Halo {nama}, harga mulai 50rb)", "")
        btn("Tambah aturan") {
            val k = kwIn.text.toString().trim()
            val r = rpIn.text.toString().trim()
            if (k.isEmpty() || r.isEmpty()) toast("Isi kata kunci dan balasan")
            else {
                Prefs.addRule(this, k, r)
                kwIn.setText(""); rpIn.setText("")
                renderAll()
            }
        }
        rulesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(rulesBox)

        // ---------- 5. LAINNYA ----------
        title("5. LAINNYA")
        note("Jeda antar balasan ke chat yang sama (menit), supaya tidak membalas berulang:")
        val cd = edit("Jeda (menit)", Prefs.arCooldown(this).toString())
        cd.inputType = InputType.TYPE_CLASS_NUMBER
        btn("Simpan jeda") {
            Prefs.setArCooldown(this, (cd.text.toString().toIntOrNull() ?: 30).coerceIn(0, 1440))
            toast("Disimpan")
        }

        // ---------- TES ----------
        title("TES (tanpa WhatsApp)")
        val tName = edit("Nama pengirim contoh", "Budi")
        val tMsg = edit("Isi pesan contoh", "")
        val tGroup = Switch(this).apply { text = "Anggap ini pesan dari grup" }
        col.addView(tGroup)
        val tSched = Switch(this).apply { text = "Abaikan jadwal saat tes"; isChecked = true }
        col.addView(tSched)
        val tOut = TextView(this).apply { textSize = 14f }
        btn("Tes balasan") {
            val nm = tName.text.toString().trim().ifEmpty { "Budi" }
            val r = AutoReply.evaluate(this, nm, nm, tMsg.text.toString(), tGroup.isChecked, tSched.isChecked)
            tOut.text = if (r.reply != null) "Akan membalas:\n" + r.reply else "Tidak membalas: " + r.note
        }
        col.addView(tOut)

        // ---------- RIWAYAT ----------
        title("RIWAYAT BALASAN")
        logView = TextView(this)
        col.addView(logView)
        btn("Hapus riwayat") { Prefs.clearLog(this); renderAll() }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0F1724.toInt())
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (hasAccess()) "Akses notifikasi: aktif" else "Akses notifikasi: BELUM aktif (tekan Beri akses notifikasi)"
        renderAll()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            contentResolver.query(uri, arrayOf(ContactsContract.Contacts.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) {
                    Prefs.arAdd(this, false, it.getString(0))
                    toast("Ditambahkan: " + it.getString(0))
                }
            }
            renderAll()
        }
    }

    private fun hasAccess(): Boolean =
        (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "")
            .contains(packageName)

    private fun pickTime(isFrom: Boolean) {
        val cur = if (isFrom) Prefs.arFromM(this) else Prefs.arToM(this)
        TimePickerDialog(this, { _, h, m ->
            val v = h * 60 + m
            if (isFrom) Prefs.setArTimes(this, v, Prefs.arToM(this))
            else Prefs.setArTimes(this, Prefs.arFromM(this), v)
            renderAll()
        }, cur / 60, cur % 60, true).show()
    }

    private fun updateSummary() { summary.text = AutoReply.summary(this) }

    private fun renderAll() {
        val days = Prefs.arDays(this)
        for ((d, tv) in dayChips) {
            val on = d in days
            tv.setTextColor(if (on) 0xFF0B1424.toInt() else Color.WHITE)
            tv.background = GradientDrawable().apply {
                setColor(if (on) 0xFF3DD6F5.toInt() else 0xFF1E2A3A.toInt())
                cornerRadius = dp(8).toFloat()
            }
        }
        fromBtn.text = "Mulai " + AutoReply.fmt(Prefs.arFromM(this))
        toBtn.text = "Selesai " + AutoReply.fmt(Prefs.arToM(this))
        renderList(peopleBox, false)
        renderList(groupBox, true)
        renderSeen(peopleSeen, false)
        renderSeen(groupSeen, true)
        renderRules()
        logView.text = Prefs.log(this).ifBlank { "Belum ada" }
        updateSummary()
    }

    private fun renderList(box: LinearLayout, group: Boolean) {
        box.removeAllViews()
        val items = Prefs.arList(this, group)
        if (items.isEmpty()) {
            box.addView(TextView(this).apply { text = "(daftar kosong)"; textSize = 12f })
            return
        }
        items.forEachIndexed { i, name ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(TextView(this).apply { text = name; textSize = 14f }, lp())
            row.addView(Button(this).apply {
                text = "Hapus"
                setOnClickListener { Prefs.arDel(this@AutoReplyActivity, group, i); renderAll() }
            })
            box.addView(row)
        }
    }

    private fun renderSeen(box: LinearLayout, group: Boolean) {
        box.removeAllViews()
        val have = Prefs.arList(this, group)
        val seen = Prefs.arSeen(this, group).filter { n -> have.none { it.equals(n, true) } }.take(8)
        if (seen.isEmpty()) {
            box.addView(TextView(this).apply { text = "(belum ada, tunggu ada pesan masuk di WhatsApp)"; textSize = 12f })
            return
        }
        for (n in seen) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(TextView(this).apply { text = n; textSize = 14f }, lp())
            row.addView(Button(this).apply {
                text = "+ Tambah"
                setOnClickListener { Prefs.arAdd(this@AutoReplyActivity, group, n); renderAll() }
            })
            box.addView(row)
        }
    }

    private fun renderRules() {
        rulesBox.removeAllViews()
        val rules = Prefs.arRules(this)
        if (rules.isEmpty()) {
            rulesBox.addView(TextView(this).apply { text = "(belum ada aturan kata kunci)"; textSize = 12f })
            return
        }
        rules.forEachIndexed { i, (k, r) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(TextView(this).apply { text = k + " -> " + r; textSize = 13f }, lp())
            row.addView(Button(this).apply {
                text = "Hapus"
                setOnClickListener { Prefs.delRule(this@AutoReplyActivity, i); renderAll() }
            })
            rulesBox.addView(row)
        }
    }
}
