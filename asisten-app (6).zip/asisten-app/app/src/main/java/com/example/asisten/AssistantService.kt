package com.example.asisten

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class AssistantService : AccessibilityService() {

    companion object {
        var instance: AssistantService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var commands: Commands
    private lateinit var params: WindowManager.LayoutParams
    private var box: LinearLayout? = null
    private lateinit var img: ImageView
    private lateinit var label: TextView
    private lateinit var hideBtn: TextView
    private lateinit var inputBox: TextView
    private lateinit var quickRow: LinearLayout
    private var minimized = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun fullWidth() = dp(maxOf(160, Prefs.size(this) + 80))

    override fun onServiceConnected() {
        instance = this
        commands = Commands(this)
        buildOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        removeOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    // ---------- Overlay ----------

    private fun buildOverlay() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(6), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(0xE60B1424.toInt())
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), 0xFF3DD6F5.toInt())
            }
        }
        box = b

        hideBtn = TextView(this).apply {
            text = "HIDE"
            textSize = 8f
            setTextColor(Color.WHITE)
            setPadding(dp(6), dp(1), dp(6), dp(1))
            background = GradientDrawable().apply { setColor(0xFFE53935.toInt()); cornerRadius = dp(6).toFloat() }
            setOnClickListener { setMinimized(true) }
        }
        b.addView(hideBtn)

        img = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        b.addView(img, LinearLayout.LayoutParams(dp(84), dp(84)))

        label = TextView(this).apply {
            textSize = 10f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 4
        }
        b.addView(label)

        inputBox = TextView(this).apply {
            text = "Ketuk untuk ketik perintah"
            textSize = 11f
            setTextColor(0xFFB8C7D6.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(9), dp(8), dp(9))
            background = GradientDrawable().apply {
                setColor(0xFF1E2A3A.toInt())
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), 0xFF3DD6F5.toInt())
            }
            setOnClickListener { openInput() }
        }
        b.addView(inputBox, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(4) })

        quickRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun chip(t: String, cmd: String) {
            quickRow.addView(
                TextView(this).apply {
                    text = t
                    textSize = 9f
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    setPadding(0, dp(6), 0, dp(6))
                    background = GradientDrawable().apply { setColor(0xFF1E2A3A.toInt()); cornerRadius = dp(6).toFloat() }
                    setOnClickListener { say(commands.run(cmd)) }
                },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { setMargins(dp(1), 0, dp(1), 0) }
            )
        }
        chip("Home", "home"); chip("Back", "kembali"); chip("Foto", "screenshot"); chip("Lampu", "senter")
        b.addView(quickRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(4) })

        // seret & tap maskot
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        img.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = params.x; sy = params.y; dx = e.rawX; dy = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 8 || abs(my) > 8) moved = true
                    if (moved) { params.x = sx + mx; params.y = sy + my; wm.updateViewLayout(b, params) }
                }
                MotionEvent.ACTION_UP -> if (!moved && minimized) setMinimized(false)
            }
            true
        }

        params = WindowManager.LayoutParams(
            fullWidth(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - dp(190)
            y = dp(120)
        }

        refresh()
        wm.addView(b, params)
    }

    private fun removeOverlay() {
        try { box?.let { wm.removeView(it) } } catch (_: Exception) {}
        box = null
    }

    /** Dipanggil setelah nama / gambar / ukuran diganti. */
    fun refresh() {
        val bmp = Prefs.mascot(this)
        if (bmp != null) img.setImageBitmap(bmp) else img.setImageResource(R.drawable.default_mascot)
        val s = Prefs.size(this)
        img.layoutParams = LinearLayout.LayoutParams(dp(s), dp(s))
        label.text = "Halo, saya ${Prefs.name(this)}"
        if (!minimized) params.width = fullWidth()
        box?.let { try { wm.updateViewLayout(it, params) } catch (_: Exception) {} }
    }

    fun toggleVisible() {
        box?.let { it.visibility = if (it.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
    }

    private fun setMinimized(m: Boolean) {
        minimized = m
        val v = if (m) View.GONE else View.VISIBLE
        hideBtn.visibility = v; label.visibility = v; inputBox.visibility = v; quickRow.visibility = v
        params.width = if (m) WindowManager.LayoutParams.WRAP_CONTENT else fullWidth()
        box?.let { wm.updateViewLayout(it, params) }
    }

    private fun say(t: String) { label.text = t }

    private fun openInput() {
        startActivity(
            Intent(this, InputActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        )
    }

    /** Jalankan perintah (bisa beberapa, dipisah titik koma; alias diperluas). */
    fun execute(cmd: String) {
        val parts = cmd.split(";").map { it.trim() }.filter { it.isNotEmpty() }.flatMap { p ->
            val a = Prefs.aliases(this)[p.lowercase()]
            if (a != null) a.split(";").map { it.trim() }.filter { it.isNotEmpty() } else listOf(p)
        }
        var delay = 0L
        for (p in parts) {
            handler.postDelayed({ say(commands.run(p)) }, delay)
            delay += if (p.lowercase().startsWith("buka ")) 1800L else 900L
        }
    }

    fun runCommand(cmd: String): String = commands.run(cmd)

    // ---------- Aksi untuk Commands ----------

    fun global(action: Int): Boolean = performGlobalAction(action)

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val dm = resources.displayMetrics
        val p = Path().apply {
            moveTo(dm.widthPixels * x1, dm.heightPixels * y1)
            lineTo(dm.widthPixels * x2, dm.heightPixels * y2)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 250)).build()
        return dispatchGesture(g, null, null)
    }

    fun tapText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            var x: AccessibilityNodeInfo? = n
            while (x != null) {
                if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                x = x.parent
            }
        }
        return false
    }

    fun typeText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val cur = if (f.isShowingHintText) "" else (f.text?.toString() ?: "")
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, cur + t)
        }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun paste(): Boolean {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return f.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    fun screenshot() {
        box?.visibility = View.INVISIBLE
        handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) }, 400)
        handler.postDelayed({ box?.visibility = View.VISIBLE }, 2000)
    }
}
