package com.example.asisten

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Jendela kecil khusus mengetik perintah (keyboard pasti muncul di sini). */
class InputActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(16), px(20), px(16))
        }
        col.addView(TextView(this).apply {
            text = "Perintah untuk ${Prefs.name(this@InputActivity)}"
            textSize = 16f
        })
        val et = EditText(this).apply {
            hint = "mis. buka whatsapp"
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
        }
        col.addView(et)

        fun send() {
            val c = et.text.toString().trim()
            finish()
            if (c.isNotEmpty()) {
                Handler(Looper.getMainLooper()).postDelayed({
                    AssistantService.instance?.execute(c)
                }, 600)
            }
        }
        et.setOnEditorActionListener { _, a, _ ->
            if (a == EditorInfo.IME_ACTION_GO) { send(); true } else false
        }
        col.addView(Button(this).apply { text = "Kirim"; setOnClickListener { send() } })

        setContentView(col)
        window.setGravity(Gravity.BOTTOM)
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        window.setDimAmount(0.25f)
        et.requestFocus()
    }
}
