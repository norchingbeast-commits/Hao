package com.example.asisten

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.ContactsContract
import android.provider.MediaStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Commands(private val svc: AssistantService) {

    companion object {
        const val MENU = """- buka [app / situs web]
- cari [kata]
- telepon [nama / nomor]
- wa [nama / nomor]
- senter on / senter off
- volume naik / volume turun
- scroll down / scroll up
- screenshot
- ketik [teks]  (tap dulu kolom teksnya)
- tap [teks di layar]
- catat [teks]
- catatan
- baterai
- status
- bersihkan  (hapus catatan)
- home / kembali
- tidur  (kunci layar)"""
    }

    private fun go(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        svc.startActivity(i)
    }

    fun run(raw: String): String {
        val t = raw.trim()
        val l = t.lowercase()
        fun arg(p: String) = t.substring(p.length).trim()
        return try {
            when {
                l == "menu" || l == "bantuan" -> { go(Intent(svc, MainActivity::class.java)); "Membuka Cara Pakai..." }
                l.startsWith("buka ") -> openApp(arg("buka "))
                l.startsWith("cari ") -> {
                    go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(arg("cari ")))))
                    "Mencari: ${arg("cari ")}"
                }
                l.startsWith("telepon ") -> call(arg("telepon "))
                l.startsWith("wa ") -> wa(arg("wa "))
                l == "senter on" -> torch(true)
                l == "senter off" -> torch(false)
                l == "volume naik" -> volume(AudioManager.ADJUST_RAISE)
                l == "volume turun" -> volume(AudioManager.ADJUST_LOWER)
                l == "scroll down" -> if (svc.scroll(true)) "Scroll ke bawah" else "Gagal scroll"
                l == "scroll up" -> if (svc.scroll(false)) "Scroll ke atas" else "Gagal scroll"
                l == "screenshot" -> { svc.screenshot(); "Mengambil screenshot..." }
                l.startsWith("ketik ") ->
                    if (svc.typeText(arg("ketik "))) "Teks diketik"
                    else "Tidak ada kolom teks aktif. Tap kolomnya dulu."
                l.startsWith("tap ") ->
                    if (svc.tapText(arg("tap "))) "Tap: ${arg("tap ")}" else "Teks tidak ditemukan di layar"
                l.startsWith("catat ") -> { Prefs.addNote(svc, arg("catat ")); "Catatan disimpan" }
                l == "catatan" -> Prefs.notes(svc).ifBlank { "Belum ada catatan" }
                l == "baterai" -> "Baterai ${battery()}%"
                l == "status" -> "${Prefs.name(svc)} aktif\nBaterai ${battery()}%\nJam " +
                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                l == "bersihkan" -> { Prefs.clearNotes(svc); "Catatan dibersihkan" }
                l == "home" -> { svc.global(AccessibilityService.GLOBAL_ACTION_HOME); "Home" }
                l == "kembali" -> { svc.global(AccessibilityService.GLOBAL_ACTION_BACK); "Kembali" }
                l == "tidur" -> { svc.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN); "Layar dikunci" }
                else -> "Perintah tidak dikenal. Ketik: menu"
            }
        } catch (e: Exception) {
            "Gagal: ${e.message}"
        }
    }

    private fun openApp(q: String): String {
        if (q.contains(".") && !q.contains(" ")) {
            val url = if (q.startsWith("http")) q else "https://$q"
            go(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            return "Membuka $q"
        }
        val pm = svc.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(main, 0)
        val hit = list.firstOrNull { it.loadLabel(pm).toString().equals(q, true) }
            ?: list.firstOrNull { it.loadLabel(pm).toString().contains(q, true) }
        if (hit != null) {
            val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            if (i != null) { go(i); return "Membuka ${hit.loadLabel(pm)}" }
        }
        if (q.equals("kamera", true) || q.equals("camera", true)) {
            go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); return "Membuka kamera"
        }
        return "Aplikasi '$q' tidak ditemukan"
    }

    private fun findContact(q: String): Pair<String, String>? {
        if (q.any { it.isLetter() }.not()) return q to q
        if (svc.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val c = svc.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$q%"), null
        )
        c?.use { if (it.moveToFirst()) return it.getString(0) to it.getString(1) }
        return null
    }

    private fun call(q: String): String {
        val (name, num) = findContact(q) ?: return "Kontak '$q' tidak ditemukan (cek izin Kontak)"
        val uri = Uri.parse("tel:" + Uri.encode(num))
        val granted = svc.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        go(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
        return "Menelepon $name"
    }

    private fun wa(q: String): String {
        val (name, num) = findContact(q) ?: return "Kontak '$q' tidak ditemukan (cek izin Kontak)"
        var n = num.filter { it.isDigit() }
        if (n.startsWith("0")) n = "62" + n.substring(1)
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n")))
        return "Membuka WhatsApp $name"
    }

    private fun torch(on: Boolean): String {
        val cm = svc.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Senter tidak tersedia"
        cm.setTorchMode(id, on)
        return if (on) "Senter menyala" else "Senter mati"
    }

    private fun volume(dir: Int): String {
        svc.getSystemService(AudioManager::class.java)
            .adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        return "Volume diubah"
    }

    private fun battery(): Int =
        svc.getSystemService(BatteryManager::class.java)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
}
