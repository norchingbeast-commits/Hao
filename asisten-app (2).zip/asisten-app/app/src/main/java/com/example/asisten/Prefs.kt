package com.example.asisten

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("asisten", Context.MODE_PRIVATE)

    fun name(c: Context): String = sp(c).getString("name", "Ariel") ?: "Ariel"
    fun setName(c: Context, v: String) = sp(c).edit().putString("name", v).apply()

    fun notes(c: Context): String = sp(c).getString("notes", "") ?: ""
    fun addNote(c: Context, t: String) =
        sp(c).edit().putString("notes", (notes(c) + "- " + t + "\n")).apply()
    fun clearNotes(c: Context) = sp(c).edit().remove("notes").apply()

    fun mascotFile(c: Context) = File(c.filesDir, "mascot.png")
    fun mascot(c: Context): Bitmap? {
        val f = mascotFile(c)
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }
}
