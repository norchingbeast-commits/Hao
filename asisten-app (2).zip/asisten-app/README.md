# Asisten (Android, Kotlin)

Asisten melayang dengan maskot + kotak perintah. Nama & gambar bisa diganti di dalam aplikasi.

## Cara build
1. Buka folder ini di Android Studio (Koala atau lebih baru), tunggu Gradle sync.
2. Run di HP (USB debugging) atau Build > Build APK.

## Cara pakai
1. Buka app > "Aktifkan Aksesibilitas" > pilih "Asisten" > nyalakan.
   (Android 13+: jika terblokir, Info Aplikasi > titik tiga > "Izinkan setelan terbatas".)
2. "Izinkan Kontak & Telepon".
3. "Pilih gambar maskot" dan isi nama > "Simpan nama".
4. Maskot melayang muncul. Seret untuk memindah, HIDE untuk mengecilkan, tap maskot untuk membuka lagi.

## Mengganti ID aplikasi / nama app
- applicationId & namespace: app/build.gradle.kts (dan package di folder java).
- Nama di launcher: app/src/main/res/values/strings.xml
- Perintah baru: tambah cabang di Commands.kt
